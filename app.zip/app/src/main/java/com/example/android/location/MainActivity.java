package com.example.android.location;

import android.*;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.vision.text.Text;

import java.util.ArrayList;

import static android.R.attr.data;
import static android.R.attr.y;
import static android.media.CamcorderProfile.get;


public class MainActivity extends AppCompatActivity implements GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, LocationListener {
    public TextView latitude;
    public TextView longitude;
    public ArrayList<String> Placemark;
    public ArrayList<String> Description;
    public ArrayList<String> Latitude;
    public ArrayList<String> Longitude;
    private double mlatitude;
    private double mlongitude;
    private LocationRequest mLocationRequest;
    private GoogleApiClient mGoogleApiClient;
    public final static int MY_PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION = 1; // request code to see if app has permission for access fine location granted


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //builds the GoogleApiClient to Connect to location services
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addApi(LocationServices.API)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .build();
        //initiates the lat-long views
          latitude = (TextView) findViewById(R.id.latitude);
          longitude = (TextView) findViewById(R.id.longitude);

        //initiates the text views so an onClickListener can be called
        TextView loadNewFile = (TextView) findViewById(R.id.loadNewFile);
        TextView poleList = (TextView) findViewById(R.id.poleList);
        TextView poleSingle = (TextView) findViewById(R.id.poleSingle);

        //retrieves data from @LoadNewFile
        Bundle extras = getIntent().getExtras();

        //gets bundle attached to intent which has the arrays with information
        if(extras!=null) {
            Placemark = extras.getStringArrayList("Placemark");
            Description = extras.getStringArrayList("Description");
            Latitude = extras.getStringArrayList("Latitude");
            Longitude = extras.getStringArrayList("Longitude");
        }


        //sets an onClickListener for the @loadNewFile which will connect to GoogleDrive.. currently just loads kml in assets folder
        loadNewFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                    Intent i = new Intent(MainActivity.this, LoadNewFile.class);
                    startActivity(i);
            }
        });

        //sets an onClickListener for the @poleList which will load all the poles in the currently loaded kml file
        poleList.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                if(Placemark!=null){
                    Intent i = new Intent(MainActivity.this, PoleList.class);
                    Bundle b = new Bundle();
                    b.putStringArrayList("Placemark", Placemark);
                    b.putStringArrayList("Description", Description);
                    i.putExtras(b);
                    startActivity(i);
                }else{
                    Toast nokmlFile = Toast.makeText(MainActivity.this, "No kml file selected", Toast.LENGTH_SHORT); //notifies the user if they have not yet imported a kml file
                    nokmlFile.show();
                    return;
                }
            }
        });

        //sets onClickListener for @poleSingle which will lookup a single pole information in the line
        poleSingle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    if(Placemark!=null){
                        Intent i = new Intent(MainActivity.this, PoleInfo.class);
                        Bundle b = new Bundle();
                        b.putStringArrayList("Placemark", Placemark);
                        b.putStringArrayList("Description", Description);
                        b.putStringArrayList("Latitude", Latitude);
                        b.putStringArrayList("Longitude", Longitude);
                        b.putDouble("mlatitude", mlatitude);
                        b.putDouble("mlongitude",mlongitude);
                        i.putExtras(b);
                        startActivity(i);
                    }else{
                        Toast nokmlFile = Toast.makeText(MainActivity.this, "No kml file selected", Toast.LENGTH_SHORT); //notifies the user if they have not yet imported a kml file
                        nokmlFile.show();
                        return;
                    }
            }

        });

    }

    //starts location services from the GoogleAPIClient to requests location
    @Override
    public void onConnected(Bundle bundle) {
        //creates a location request which sets priority and time interval for retrieving location
        mLocationRequest = LocationRequest.create();
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        mLocationRequest.setInterval(100);//Unit of measure is in milliseconds


        //Checks to see if location permissions are granted. If they are not, generates a new request
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(MainActivity.this, new String[] {Manifest.permission.ACCESS_FINE_LOCATION},MY_PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION );

            return;
        }
        LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, this);

    }

    @Override
    public void onConnectionSuspended(int i) {
    }
    //connects the GoogleApiClient when app starts up
    @Override
    protected void onResume() {
        super.onResume();
        mGoogleApiClient.connect();
        latitude.setText(String.valueOf(mlatitude));
        longitude.setText(String.valueOf(mlongitude));
    }
    @Override
    protected void onPause() {
        super.onPause();
        if (mGoogleApiClient.isConnected()) {
            mGoogleApiClient.disconnect();
            }
    }
    @Override
    protected void onStart() {
        super.onStart();
        mGoogleApiClient.connect();
    }
    //disconnects the GoogleApiClient when app stops
    @Override
    protected void onStop(){
        super.onStop();
        mGoogleApiClient.disconnect();
    }
    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {
    }
    //location services calls back with new location which is then updated
    @Override
    public void onLocationChanged(Location location) {
        mlatitude = location.getLatitude();
        mlongitude = location.getLongitude();
        latitude.setText(String.valueOf(mlatitude));
        longitude.setText(String.valueOf(mlongitude));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int [] grantResults){
        switch(requestCode){
            case MY_PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION: {
                if (grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED){
                    Toast permissionGranted = Toast.makeText(MainActivity.this, "Permission Granted \n Thanks!", Toast.LENGTH_SHORT);
                    permissionGranted.show();
                } else {
                    mGoogleApiClient.disconnect(); //disconnects Google Location API client because permission were not granted
                    Toast noPermissionGranted = Toast.makeText(MainActivity.this, "No Permission Granted \n Cannot use Location Services", Toast.LENGTH_SHORT);
                    noPermissionGranted.show();
                }
            }

        }
    }
}

