package com.example.android.location;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.Toast;

import java.util.ArrayList;

import static android.media.CamcorderProfile.get;
import static com.example.android.location.R.id.poleList;

public class PoleList extends AppCompatActivity {
    public ArrayList<String> Placemark;
    public ArrayList<String> Description;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pole_list);
        //creates an list of placemarks from the kml file

        Bundle extras = getIntent().getExtras();

        //gets bundle attached to intent which has the Placemark array
        if(extras!=null) {
            Placemark = extras.getStringArrayList("Placemark");
            Description = extras.getStringArrayList("Description");

        }else {//this case should not trigger, but is added just so the app will not crash
            Placemark.add("pole 1");
            Description.add("no pole selected");
        }

        //generates the buttons on the activity_pole_list_xml with a listView
        final ArrayAdapter<String> poleListAdapter = new ArrayAdapter<String>(this, R.layout.pole_list_buttons, Placemark);
        final ListView poleList = (ListView) findViewById(R.id.pole_list);
        poleList.setAdapter(poleListAdapter);
        poleList.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?>parent, View view, int position, long id){
                int placemarkClicked = Placemark.indexOf(Placemark.get(position)); //returns the index of the placemark that was clicked

                Intent i = new Intent(PoleList.this, PoleInfo.class);
                Bundle b = new Bundle();
                b.putStringArrayList("Placemark", Placemark);
                b.putStringArrayList("Description", Description);
                b.putInt("placemarkClicked", placemarkClicked);
                i.putExtras(b);
                startActivity(i);

               // Toast clickArray = Toast.makeText(PoleList.this, Placemark.get(placemarkClicked), Toast.LENGTH_SHORT);
               // clickArray.show();
            }
        });

    }
}
