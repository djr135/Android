package com.example.android.location;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


/**
 * Created by David R on 10/17/2016.
 */

public class kmlParser {
 //   private static final String TAG = "kmlParser"; // for log events

    //gets kml stored in assets folder
    //MainActivity main = new MainActivity();
    //String kmlData = main.loadKMLFromAsset();

    //creates an array that stores the values for the tags retrieved from the kml
    private ArrayList<String> mplacemarkArray = new ArrayList<>();
    private ArrayList<String> mdescriptionArray = new ArrayList<String>();
    private ArrayList<String> mlatitudeArray = new ArrayList<String>();
    private ArrayList<String> mlongitudeArray = new ArrayList<String>();
    private List<String> mcoordinatesArray; //contains lat-long and altitude
    public ArrayList<ArrayList<String>> kmlParsedArray = new ArrayList<ArrayList<String>>();


    //sets the strings to find in the kml
    private final static String MNAME = "name";
    private final static String MPLSMODEL = "pls-cadd model";
    private final static String MPLACEMARK = "placemark";
    private final static String MDESCRIPTION = "description";
    private final static String MCOORDINATES = "coordinates";

    public ArrayList<ArrayList<String>> getParsedData(String string) throws IOException, XmlPullParserException {
        this.main(string);
        kmlParsedArray.add(mplacemarkArray);
        kmlParsedArray.add(mdescriptionArray);
        kmlParsedArray.add(mlatitudeArray);
        kmlParsedArray.add(mlongitudeArray);
        return kmlParsedArray;
    }




    //makes an Xml Parser that checks for the tags specified above
    public void main(String kmlData)
        throws XmlPullParserException, IOException { //will throw an exception if an error is encountered
        XmlPullParserFactory factory = XmlPullParserFactory.newInstance(); //creates a new parser
        factory.setNamespaceAware(true);

        String nameCheck = ""; //used to check parser name tags

        XmlPullParser kmlParser = factory.newPullParser();
        kmlParser.setInput(new StringReader(kmlData));
        int eventType = kmlParser.getEventType();
        while (eventType != XmlPullParser.END_DOCUMENT && !nameCheck.equalsIgnoreCase(MPLSMODEL)) {   //runs the while loop until the last tag in document or PLS-Model name is encountered
                if (eventType == XmlPullParser.START_TAG){
                    String tagName = kmlParser.getName();  //retrieves name of current tag
                    if(tagName.equalsIgnoreCase(MNAME)) {
                        eventType = kmlParser.next(); //move on to next event
                        nameCheck = kmlParser.getText();
                    }

                    //if it reaches the PLS-CADD model folder, the parser has gotten all the structure locations
                    if(eventType == XmlPullParser.START_TAG) {
                            String tagName2 = kmlParser.getName();  //retrieves name of current tag
                            String mcoordinates;
                            //finds which array to place text following the tag
                            switch (tagName2.toLowerCase()) {
                                case MPLACEMARK:
                                    kmlParser.next();
                                    kmlParser.next();
                                    kmlParser.next();
                                    mplacemarkArray.add(kmlParser.getText());
                                    break;
                                case MDESCRIPTION:
                                    kmlParser.next();
                                    if(mdescriptionArray.size()<mplacemarkArray.size()){ //this will make sure that the description pertains to a pole number
                                    mdescriptionArray.add(kmlParser.getText());
                                    }
                                    break;
                                case MCOORDINATES: //find coordinates tag and break it down into latitude and longitude with comma delimiter
                                    kmlParser.next();
                                    mcoordinates = kmlParser.getText();
                                    mcoordinatesArray = Arrays.asList(mcoordinates.split("\\s*,\\s*")); //separates the coordinates tag into array
                                    mlongitudeArray.add(mcoordinatesArray.get(0));
                                    mlatitudeArray.add(mcoordinatesArray.get(1));
                                  //maltitudeArray.add(mcoordinates.get(2)); //can also retrieve altitude of point
                                    break;
                                default:
                                    break;
                    }
                }
             }
            eventType = kmlParser.next(); //move on to next event
        }
    }

}

