package com.example.android.location;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import static android.R.attr.onClick;
import static com.example.android.location.R.id.loadNewFile;


public class LoadNewFile extends AppCompatActivity {
    //initializes array lists for storing the kml file values
    public ArrayList<String> kmlPlacemarks = new ArrayList<String>();
    public ArrayList<String> kmlDescriptions = new ArrayList<String>();
    public String kmlData = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_load_new_file);



        //sets the buttons to click whichever test case you want
        TextView test1 = (TextView) findViewById(R.id.button1);
        TextView test2 = (TextView) findViewById(R.id.button2);

        test1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                kmlData = loadKMLFromAsset("test_kml.kml");
                loadData();
            }
        });

        test2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                kmlData = loadKMLFromAsset("test_kml2.kml");
                loadData();
            }
        });



    }

    //Loads the kml in the assets folder
    public String loadKMLFromAsset(String kmlToLoad) {
        String kmlData = null;
        try {
            InputStream is = getAssets().open(kmlToLoad);//This is the file located in the assets folder
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);  // reads the file and sets it to variable buffer
            is.close();       //closes connection to file
            kmlData = new String(buffer, "UTF-8"); //sets kmlData to XML with UTF-8 encoding
        }
        //if app encounters an error it returns null
        catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        //returns kml in String format
        return kmlData;
    }

    //loads the kml file that was clicked on
    public void loadData(){
        kmlParser getData = new kmlParser(); //instatiates the kmlParser class
        ArrayList<ArrayList<String>> kmlArray = null;
        try {
            kmlArray = getData.getParsedData(kmlData);
            /* 0 Placemark name Array
               1 Description Array
               2 Latitude Array
               3 Longitude Array
             */
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e) {
            e.printStackTrace();
        }
        //retrieves arrays from parsed kmlArray
        ArrayList<String> Placemark = kmlArray.get(0);
        ArrayList<String> Description = kmlArray.get(1);
        ArrayList<String> Latitude = kmlArray.get(2);
        ArrayList<String> Longitude = kmlArray.get(3);

        // TextView testView = (TextView) findViewById(R.id.test);
        // testView.setText(Placemark.get(4));


        Intent i = new Intent(LoadNewFile.this, MainActivity.class); //sends new intent to send back to MainActivity
        Bundle b = new Bundle();
        b.putStringArrayList("Placemark", Placemark);
        b.putStringArrayList("Description", Description);
        b.putStringArrayList("Latitude", Latitude);
        b.putStringArrayList("Longitude", Longitude);
        i.putExtras(b); //adds extras bundle to intent
        startActivity(i);
    }
}


