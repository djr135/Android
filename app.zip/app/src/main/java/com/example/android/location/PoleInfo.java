package com.example.android.location;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import static android.R.attr.description;
import static android.R.attr.type;
import static com.google.android.gms.internal.zznu.it;

public class PoleInfo extends AppCompatActivity {
    public ArrayList<String> Placemark;
    public ArrayList<String> Description;
    public ArrayList<String> Latitude;
    public ArrayList<String> Longitude;
    public double currentLatitude;
    public double currentLongitude;
    public int placemarkClicked;
    public int index;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Can't initialize content view until after you set the requestWindowFeature
        setContentView(R.layout.activity_pole_info);

        Bundle extras = getIntent().getExtras();

        //gets bundle attached to intent which has the Placemark array
        if(extras!=null) {
            Placemark = extras.getStringArrayList("Placemark");
            Description = extras.getStringArrayList("Description");
            Latitude = extras.getStringArrayList("Latitude");
            Longitude = extras.getStringArrayList("Longitude");
            placemarkClicked = extras.getInt("placemarkClicked");
            currentLatitude = extras.getDouble("mlatitude");
            currentLongitude = extras.getDouble("mlongitude");

        }

        //checks to see which index value will be used. If user came from PoleList activity, placemark Clicked
        //will be used, else if user came from clicking pole location button from Main activity, current lat-long
        //will be used instead

        if (placemarkClicked!=0){
             index = placemarkClicked;
        }else if(currentLatitude!= 0.){
            index = getNearestLocation(currentLatitude, currentLongitude, 0.);
        }else{
            index = 0;
        }

        //sets title bar to pole number
        setTitle(Placemark.get(index));


        //sets value at index found in getNearestlocation method or from pole clicked in PoleList
        //after passing it through the formatting method
        //to the textviews in pole info activity
        ArrayList<String> formattedText = formatDescription( Placemark.get(index), Description.get(index));

        //makes new arrayadapter to hold the different lines of the pole description
        final ArrayAdapter<String> poleDescriptionAdapter = new ArrayAdapter<String>(this, R.layout.pole_description_rows, formattedText);
        final ListView poleList = (ListView) findViewById(R.id.pole_list);

        poleList.setAdapter(poleDescriptionAdapter);

//        TextView description = (TextView)findViewById(R.id.description);
//            description.setText(formattedText.get(1));

    }

    //calculates distance to each placemark on kml given the lat-long from location listener
    //placeholder variable is not used, but method is not properly getting the longitude variable without it

    private int getNearestLocation(double latitude, double longitude, double placeholder){
        int index = 0; //just in case there is no values to nearest threshold
        double dLat;
        double dLng;
        double polarRadius = 6356750.; //polar radius of earth in meters
        double distance;
        double threshold = 50; // this is actually in meters

        //iterates through every placemark available and returns index of minimum distance
        for(int i = 0; i<Placemark.size();i++){
            dLat = Math.toRadians(Double.parseDouble(Latitude.get(i)) - latitude);
            dLng = Math.toRadians(Double.parseDouble(Longitude.get(i)) - longitude);
            double a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                    Math.cos(Math.toRadians(latitude)) * Math.cos(Math.toRadians(longitude)) *
                            Math.sin(dLng/2) * Math.sin(dLng/2);
            double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
            distance = (polarRadius * c);

            //finds index of placemark that is the minimum distance from the current lat-long, but also within the threshold
            if(distance<threshold){
                threshold = distance;
                index = i;
            }
        }

        return index;
    }
    //formats the Description String so that it can be organized and filtered in the pole layout view
    private ArrayList<String> formatDescription(String Placemark, String Description) {
        ArrayList<String> mformattedDescription = new ArrayList<String>();
        String[] mdescription = Description.split("\\r?\\n");
        for(int i= 0; i < mdescription.length; i++) {
            if(!mdescription[i].equalsIgnoreCase(Placemark)){
               mformattedDescription.add(mdescription[i]);
            }

        }
        return mformattedDescription;
    }
}
